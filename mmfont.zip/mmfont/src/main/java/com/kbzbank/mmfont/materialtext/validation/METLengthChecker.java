package com.kbzbank.mmfont.materialtext.validation;

public abstract class METLengthChecker {

    public abstract int getLength(CharSequence text);

}
